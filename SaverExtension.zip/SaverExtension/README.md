# SaverExtension
Saves Tabs in Session so that you can save RAM and Battery
